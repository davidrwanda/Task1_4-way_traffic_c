/*
 * File:   main.c
 * Author: ram_bridge
 *
 * Created on July 23, 2021, 8:08 AM
 */


// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = ON         // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3/PGM pin has PGM function; low-voltage programming enabled)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#define _XTAL_FREQ 4000000
#include <xc.h>
void main() {
TRISB =  0b00000000;  
TRISC =  0b00000000;
TRISD =  0b00000000;

while(1){
       A: 
        PORTBbits.RB0=0;
        PORTBbits.RB1=1;
        PORTBbits.RB2=0;
        
        PORTBbits.RB4=0; 
        PORTBbits.RB5=0;
        PORTBbits.RB6=1;
        
        PORTCbits.RC3=1;
        PORTCbits.RC4=0;
        PORTCbits.RC5=0;
        
        PORTCbits.RC0=1;
        PORTCbits.RC1=0;
        PORTCbits.RC2=0;
        
        PORTDbits.RD0=1;
        PORTDbits.RD1=0;
        PORTDbits.RD2=0;
        __delay_ms(5000);
        goto B;
    
       B:    
        PORTBbits.RB0=1;
        PORTBbits.RB1=0;
        PORTBbits.RB2=0;
        
        PORTBbits.RB4=0; 
        PORTBbits.RB5=1;
        PORTBbits.RB6=0;
        
        PORTCbits.RC3=0;
        PORTCbits.RC4=0;
        PORTCbits.RC5=1;
        
        PORTCbits.RC0=1;
        PORTCbits.RC1=0;
        PORTCbits.RC2=0;
        
        PORTDbits.RD0=1;
        PORTDbits.RD1=0;
        PORTDbits.RD2=0;
        __delay_ms(5000);
        goto C;
        
       C:       
        PORTBbits.RB0=1;
        PORTBbits.RB1=0;
        PORTBbits.RB2=0;
        
        PORTBbits.RB4=1; 
        PORTBbits.RB5=0;
        PORTBbits.RB6=0;
        
        PORTCbits.RC3=0;
        PORTCbits.RC4=1;
        PORTCbits.RC5=0;
        
        PORTCbits.RC0=0;
        PORTCbits.RC1=0;
        PORTCbits.RC2=1;
        
        PORTDbits.RD0=1;
        PORTDbits.RD1=0;
        PORTDbits.RD2=0;
        __delay_ms(5000);
        goto D;
        
       D:
        PORTBbits.RB0=1;
        PORTBbits.RB1=0;
        PORTBbits.RB2=0;
        
        PORTBbits.RB4=1; 
        PORTBbits.RB5=0;
        PORTBbits.RB6=0;
        
        PORTCbits.RC3=1;
        PORTCbits.RC4=0;
        PORTCbits.RC5=0;
        
        PORTCbits.RC0=0;
        PORTCbits.RC1=1;
        PORTCbits.RC2=0;
        
        PORTDbits.RD0=0;
        PORTDbits.RD1=0;
        PORTDbits.RD2=1;
        __delay_ms(5000);
        goto E;
        E:
        PORTBbits.RB0=0;
        PORTBbits.RB1=0;
        PORTBbits.RB2=1;
        
        PORTBbits.RB4=1; 
        PORTBbits.RB5=0;
        PORTBbits.RB6=0;
        
        PORTCbits.RC3=1;
        PORTCbits.RC4=0;
        PORTCbits.RC5=0;
        
        PORTCbits.RC0=1;
        PORTCbits.RC1=0;
        PORTCbits.RC2=0;
        
        PORTDbits.RD0=0;
        PORTDbits.RD1=1;
        PORTDbits.RD2=0;
        __delay_ms(5000);
        goto A;
         
 }
}
